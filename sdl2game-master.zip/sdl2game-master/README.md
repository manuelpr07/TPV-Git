Some SDL2 graphics

Requires: `SDL2`, `SDL2-image`, `SDL2-ttf`
