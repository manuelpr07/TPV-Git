#include "Wall.h"

void Wall::render()
{
	ArcanoidObject::render();
}

