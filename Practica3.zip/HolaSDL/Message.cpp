#include "Message.h"

void Message::render()
{
	ArcanoidObject::render();
}