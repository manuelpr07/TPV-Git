#include "GameObject.h"

GameObject::GameObject()
{

}
void GameObject::render()
{

}
void GameObject::update()
{

}
