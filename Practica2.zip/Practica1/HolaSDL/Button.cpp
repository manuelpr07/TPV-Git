#include "Button.h"
#include "Game.h"

void Button::render()
{
	ArcanoidObject::render();
}