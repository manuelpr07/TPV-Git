#include "GameObject.h"

GameObject::GameObject()
{

}
void GameObject::render()
{

}
void GameObject::update()
{

}
void GameObject::handdleEvents(SDL_Event event)
{

}